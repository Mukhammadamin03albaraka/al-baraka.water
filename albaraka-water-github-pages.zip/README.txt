AL-BARAKA WATER — сайт для GitHub Pages

Файлы (все лежат в корне, папок нет, так проще загружать с iPhone):
  index.html  — главная страница (RU/UZ, заказ, цены, виды воды)
  style.css   — оформление
  script.js   — функции (языки, калькулятор, окно звонка, панель заказа)
  logo.png    — логотип без фона
  404.html    — страница «не найдено»

Как опубликовать:
1. Зайдите на github.com, войдите в аккаунт и нажмите «New repository».
2. Название, например, albaraka-water, доступ Public, нажмите «Create repository».
3. Нажмите «uploading an existing file» и загрузите 5 файлов: index.html, style.css, script.js, logo.png, 404.html. Нажмите «Commit changes».
4. Откройте Settings, затем Pages. В разделе Branch выберите main и папку / (root), нажмите Save.
5. Через 1–2 минуты сайт откроется по адресу https://ИМЯ.github.io/albaraka-water/

Свой домен (например albarakasuv.uz): в Settings → Pages впишите домен в поле Custom domain
и настройте DNS у регистратора по подсказкам GitHub. Включите Enforce HTTPS.
